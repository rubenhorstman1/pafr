import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class Train implements Serializable {
    private List<Wagon> wagons = new ArrayList<>();
    private String name;

    public List<Wagon> getWagons() {
        return wagons;
    }

    public void setWagons(List<Wagon> wagons) {
        this.wagons = wagons;
    }

    public void RemoveWagon(Wagon wagon) {
        wagons.remove(wagon);
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void AddWagon(Wagon wagon) {
        wagons.add(wagon);
    }

    public Train(String name) {
        this.name = name;
    }
}
