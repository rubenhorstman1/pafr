import java.io.Serializable;

public class Wagon implements Serializable{
    private String type;
    private int id;

    public int getId() {
        return id;
    }

    public Wagon(String type, int id) {
        this.type = type;
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
